//
//  vect.hpp
//  Project 2
//
//  Created by Tess Daughton
//  Copyright © 2015 Tess Daughton. All rights reserved.
//

//
//  vect.cpp
//  Assignment 3
//
//  Created by Emma Gould.
//  Copyright © 2015 Emma Gould. All rights reserved.
//

#include "vect.hpp"
//using namespace std;

// member functions
void vect::setValues(float a, float b, float c) {
    x = a;
    y = b;
    z = c;
}
